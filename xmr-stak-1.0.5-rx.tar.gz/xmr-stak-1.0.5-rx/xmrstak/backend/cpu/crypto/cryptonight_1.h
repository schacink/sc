#pragma once

void* getRandomXDataset(const size_t numaId);

uint64_t getRandomXDatasetSize();
