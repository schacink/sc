<a href="https://github.com/fireice-uk/xmr-stak/tree/master/doc/README.md" _target="blank"><img src="doc/_img/gpu.png"></a>
<a href="#select_coin" _target="blank"><img src="doc/_img/cpu.png"></a>
<table>
    <p id="select_coin">
    <tr>
        <td align="center"><a href=https://github.com/xmrig/xmrig><img src="doc/_img/xmrig.png"></a></td>
        <td align="center"><a href=https://ragerx.lol><img src="doc/_img/ragerx.png"></a></td>
        <td align="center"><a href=doc/README.md><img src="doc/_img/rx.png"></a></td>
    </tr>
</table>