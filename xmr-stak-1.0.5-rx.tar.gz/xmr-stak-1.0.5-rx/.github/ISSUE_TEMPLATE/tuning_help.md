---
name: Need help for optimization.
about: You need help to optimize your setup.

---

**Please use the [xmr-stak sub-reddit](https://www.reddit.com/r/XmrStak/) to discuss optimizations.**
